//
//  ViewController.m
//  RKBIDemo
//
//  Created by rekoo on 2017/3/29.
//  Copyright © 2017年 rekoo. All rights reserved.
//

#import "ViewController.h"
#import <RKBISDK/RKBISDK.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view, typically from a nib.
}


/**
 发送含参BI统计
 */
- (IBAction)sendParametersBIData {
    // 1.添加 action事件
    int arc0 = arc4random() % 20;
    NSString *key = [NSString stringWithFormat:@"action%d", arc0];
    RKBIEvent *event =  [RKBIEvent rkBIAddAction:key];
    
    
    int arc1 = arc4random() % 100;
    int arc2 = arc4random() % 50;
    
    NSString *key1 = [NSString stringWithFormat:@"name%d", arc1];
    NSString *value1 = [NSString stringWithFormat:@"%d", arc1];
    
    NSString *key2 = [NSString stringWithFormat:@"tag%d", arc2];
    NSString *value2 = [NSString stringWithFormat:@"%d", arc2];
    
    // 2.给此action事件添加参数
    [event rkBIAddEvent:key1 value:value1];
    [event rkBIAddEvent:key2 value:value2];
    
    // 3.保存发送此action事件
    [RKBIPlatform rkTrackEvent:event];
}

/**
 发送无参BI统计
 */
- (IBAction)sendEmptyParametersBIData {
    // 1.添加 action事件
    int arc0 = arc4random() % 20;
    NSString *key = [NSString stringWithFormat:@"action%d", arc0];
    RKBIEvent *event =  [RKBIEvent rkBIAddAction:key];
    
    // 3.保存发送此action事件
    [RKBIPlatform rkTrackEvent:event];
}

/**
 立即发送BI统计
 仅用作检验服务器是否收到立即收到统计数据，正常情况下的统计数据会150秒自动发送给服务器
 */
- (IBAction)sendBIImmediately {
    /// 注意：此接口仅作为测试时使用
    [RKBINetworkManager sendBIRequest];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
